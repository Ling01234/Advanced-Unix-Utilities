#!/bin/bash

#verify that only one argument is giving to the script
if [[ $# -ne 1 ]] 
then 
echo "Usage: ./dataformatter.sh sensorlogdir"
#exit the script if the number of arguments given is not 1
exit 1
fi

#verify that the given directory is a valid directory
if [[ ! -d "$1" ]] 
then
echo "Error! $1 is not a valid directory name"
#exit the script if the given directory is not valid
exit 1
fi

#initialize variables to replace "ERROR" if a certain sensor reports so
a=0
b=0
c=0
d=0
e=0

#iterate through each file that matches the pattern of interest
for f in $(find $1 -name 'sensordata-*.log')
do 

echo "Processing sensor data set for $f"
echo "Year,Month,Hour,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5"

#use grep to select only the lines of interests
#pipe the output of grep into sed
#use sed to replace all hyphens on the date format by colons and all white spaces by colons
#pipe output of sed into awk
#change the input field separators and output field separators as appropriate
grep -i 'sensor readouts' $f | sed -e 's/-/:/' -e 's/-/:/' -e 's/ /:/g' | awk ' BEGIN { FS=":"; OFS="," }

#since the first reading will have no error, we can store the first reading of the day into a variable for each sensor
#for iterations that are not the first, in the case that a sensor reads "ERROR", the sensor will take the value of the previous reading, stored into a specific variable
{ if ($10 == "ERROR") { $10=a } }
{ if ($11 == "ERROR") { $11=b } }
{ if ($12 == "ERROR") { $12=c } }
{ if ($13 == "ERROR") { $13=d } }
{ if ($14 == "ERROR") { $14=e } }

#store the reading of a sensor into their respective variables
#this is used for the following hour, so that the script can correct the output in case it displays "ERROR" 
{ a=$10 }
{ b=$11 }
{ c=$12 }
{ d=$13 }
{ e=$14 }

#displaying required information
{ print $1, $2, $3, $4, $10, $11, $12, $13, $14 }'
echo "===================================="
echo "Readout statistics"
echo "Year,Month,Hour,MaxTemp,MaxSensor,MinTemp,MinSensor"

#use grep to select only the lines of interests
#pipe the output of grep into sed
#use sed to replace all hyphens on the date format by colons and all white spaces by colons
#pipe output of sed into awk
#change the input field separators and output field separators as appropriate
grep -i 'sensor readouts' $f | sed -e 's/-/:/' -e 's/-/:/' -e 's/ /:/g' | awk ' BEGIN { FS=":"; OFS="," }

#use a for loop to iterate through the numbers 10 to 14, which are the number of fields of interest since $i represents the ith field
#initialize values for the variables max and min
#makes sure that max and min never store the string "ERROR"
{ for (i = 10; i<= 14; i++) { if ($i != "ERROR") { max=$i; min=$i; break } } }

#for loop to correctly determine the minimum and maximum value for each hour
{ for (i = 10; i <= 14 ; i++) { if ($i != "ERROR" && max < $i) { max=$i }; if ($i != "ERROR" && min > $i) { min=$i } } }

#check which sensor is the one that sensed the maximum and minimum temperature
#the ordering assures that if two sensors senses the same temperature, then the one with the smaller numerical value is the one displayed
#this means that if Sensor3 and Sensor4 both sensed a minimum or maximum temperature, then Sensor3 will be associated with minSensor or maxSensor, depending. 
{ if (max == $14) { maxSensor="Sensor5" } }
{ if (max == $13) { maxSensor="Sensor4" } }
{ if (max == $12) { maxSensor="Sensor3" } }
{ if (max == $11) { maxSensor="Sensor2" } }
{ if (max == $10) { maxSensor="Sensor1" } }
{ if (min == $14) { minSensor="Sensor5" } }
{ if (min == $13) { minSensor="Sensor4" } }
{ if (min == $12) { minSensor="Sensor3" } }
{ if (min == $11) { minSensor="Sensor2" } }
{ if (min == $10) { minSensor="Sensor1" } }

#print out required information
{ print $1, $2, $3, $4, max, maxSensor, min, minSensor }'
echo "===================================="
done


echo "Sensor error statistics"
echo "Year,Month,Day,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5,Total"

#for loop to iterate through each file of interest
for f in $(find $1 -name 'sensordata-*.log')
do

#use grep to select only the lines of interests
#pipe the output of grep into sed
#use sed to replace all hyphens on the date format by colons and all white spaces by colons
#pipe output of sed into awk
#change the input field separators and output field separators as appropriate
#create variables in awk as counter variables for the number of errors each sensor will report
grep -i 'sensor readouts' $f | sed -e 's/-/:/' -e 's/-/:/' -e 's/ /:/g' | awk ' BEGIN { FS=":"; OFS=","; a1=0; a2=0; a3=0; a4=0; a5=0 }

#increment counter variable by 1 if a sensor reported an error
{ if ($10 == "ERROR") a1++ }
{ if ($11 == "ERROR") a2++ }
{ if ($12 == "ERROR") a3++ }
{ if ($13 == "ERROR") a4++ }
{ if ($14 == "ERROR") a5++ }

#print out required information
{ if ($4==23) print $1, $2, $3, a1, a2, a3, a4, a5, a1+a2+a3+a4+a5 }
'
#pipe the output of for loop into the sort command
#change the field seperator to a comma instead of white spaces
#sort the numerical value in reverse, which is the nineth key of the line
#in case of a tie, sort the year, which is the first key of the line
#in case of a tie, sort the month which is the second key of the line
#in case of a tie, sort the date which is the third key of the line
done | sort -t ',' -nrk9,9 -k1,1n -k2,2n -k3,3n
echo "===================================="
